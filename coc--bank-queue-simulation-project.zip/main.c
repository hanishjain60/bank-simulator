#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

typedef struct Customer {
    int arrival_time;
    int service_start_time;
    int service_end_time;
    struct Customer* next;
} Customer;

// Function for a Poisson random number
int poissonRandom(double lambda) {
    double L = exp(-lambda);
    double p = 1.0;
    int k = 0;

    do {
        k++;
        p = p*((double)rand() / RAND_MAX);
    } while (p > L);

    return k - 1;
}

// Function to calculate mean ,median ,mode,standard deviation,max. wait
void calculateStats(int* waits, int count) {
    if (count == 0) {
        printf("No customers served.\n");
        return;
    }

    double sum = 0;
    int max = waits[0];

    for (int i = 0; i < count; i++) {
        sum += waits[i];
        if (waits[i] > max)
            max = waits[i];
    }

    double mean = sum / count;
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (waits[i] > waits[j]) {
                int temp = waits[i];
                waits[i] = waits[j];
                waits[j] = temp;
            }
        }
    }

    double median;
    if (count % 2 == 0)
        median = (waits[count / 2 - 1] + waits[count / 2]) / 2.0;
    else
        median = waits[count / 2];

    // Mode
    int mode = waits[0], modeCount = 1, tempCount = 1;
    for (int i = 1; i < count; i++) {
        if (waits[i] == waits[i - 1])
            tempCount++;
        else
            tempCount = 1;

        if (tempCount > modeCount) {
            modeCount = tempCount;
            mode = waits[i];
        }
    }

    // Standard Deviation
    double variance = 0.0;
    for (int i = 0; i < count; i++) {
        variance += pow(waits[i] - mean, 2);
    }
    variance /= count;
    double stddev = sqrt(variance);

    printf("\n=== Queue Simulation Report ===\n");
    printf("Total Customers Served: %d\n", count);
    printf("Mean Wait Time: %.2f minutes\n", mean);
    printf("Median Wait Time: %.2f minutes\n", median);
    printf("Mode Wait Time: %d minutes\n", mode);
    printf("Standard Deviation: %.2f minutes\n", stddev);
    printf("Longest Wait Time: %d minutes\n", max);
}

// Main simulation
int main() {
    srand(time(NULL));

    double lambda;
    printf("Enter average number of customers arriving per minute (λ): ");
    scanf("%lf", &lambda);

    int simulationTime = 480; // 8 hours
    int tellerBusyUntil = 0;
    int currentTime;

    Customer* head = NULL;
    Customer* tail = NULL;
    int* waitTimes = (int*)malloc(5000 * sizeof(int)); // Dynamic wait storage
    int waitCount = 0;

    for (currentTime = 0; currentTime < simulationTime; currentTime++) {
        int arrivals = poissonRandom(lambda);

        // Add new arrivals to queue
        for (int i = 0; i < arrivals; i++) {
            Customer* newCustomer = (Customer*)malloc(sizeof(Customer));
            newCustomer->arrival_time = currentTime;
            newCustomer->next = NULL;

            if (tail == NULL) {
                head = tail = newCustomer;
            } else {
                tail->next = newCustomer;
                tail = newCustomer;
            }
        }

        if (currentTime >= tellerBusyUntil && head != NULL) {
            Customer* serving = head;
            head = head->next;
            if (head == NULL)
                tail = NULL;

            serving->service_start_time = currentTime;
            int serviceTime = 2 + rand() % 2; // 2–3 minutes
            serving->service_end_time = currentTime + serviceTime;
            tellerBusyUntil = serving->service_end_time;

            int waitTime = serving->service_start_time - serving->arrival_time;
            waitTimes[waitCount++] = waitTime;

            free(serving);
        }
    }

    calculateStats(waitTimes, waitCount);
    free(waitTimes);

    // Free any remaining customers
    while (head != NULL) {
        Customer* temp = head;
        head = head->next;
        free(temp);
    }

    return 0;
}
